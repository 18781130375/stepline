<?php

namespace Drupal\migrate\Event;

/**
 * Wraps a pre- or post-import event for event listeners.
 */
class MigrateImportEvent extends EventBase {}
